## Credictor

Package containing a credits predictor. 

Given a video file, applies a Random Forest classifier to mark which 
frames belong to the ending credits sequence, then uses the marked frames 
to determine the start of the credits in milliseconds. 

#### Installing  

The package is published in artifactory. To install it, run:

```
pip install credictor 
--index-url=https://artifactory.globoi.com/artifactory/api/pypi/pypi-all/simple
```

#### Usage

```
from credictor import CreditsPredictor

predictor = CreditsPredictor()
credits_start_time = predictor.predict('path/to/video.mp4')
```

#### Testing 

Tests can be run by executing `pytest`.
 
#### Uploading package

After changes, a new package can be uploaded to the [artifactory](https://artifactory.globoi.com).
Login and generate or renew the API key needed for the upload. 

Add the following to the ~/.pypirc file:
```
[distutils]
index-servers =
  pypi-local
  ipypi-local
[pypi-local]
repository: https://artifactory.globoi.com/artifactory/api/pypi/pypi-local
username: saml_user
password: saml_api_key
[ipypi-local]
repository: https://artifactory.globoi.com/artifactory/api/pypi/ipypi-local
username: saml_user
password: saml_api_key
```

The package can then be published:
```
$ python setup.py sdist upload -r pypi-local
```

The above upload method is in deprecation. Alternatively, use `twine`:
```
$ python setup.py sdist bdist_wheel
$ python twine upload -r pypi-local dist/[package to upload]
```

 


